/**
 * Game entities definitions
 */

class Player {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.radius = CONFIG.player.radius;
    this.color = CONFIG.player.color;
    this.speed = CONFIG.player.speed;
    this.dx = 0;
    this.dy = 0;
  }

  update(moveJoystick) {
    // Update player position based on movement joystick
    if (moveJoystick.active) {
      this.dx = (moveJoystick.x / CONFIG.game.joystickMaxDistance) * this.speed;
      this.dy = (moveJoystick.y / CONFIG.game.joystickMaxDistance) * this.speed;
    } else {
      this.dx = 0;
      this.dy = 0;
    }
    
    this.x += this.dx;
    this.y += this.dy;
  }

  draw(ctx) {
    ctx.beginPath();
    ctx.arc(this.x, this.y, this.radius, 0, Math.PI * 2);
    ctx.fillStyle = this.color;
    ctx.fill();
    ctx.closePath();
  }
}

class Enemy {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.radius = CONFIG.enemy.baseRadius;
    this.color = CONFIG.enemy.color;
    this.speed = CONFIG.enemy.minSpeed + Math.random() * (CONFIG.enemy.maxSpeed - CONFIG.enemy.minSpeed);
    this.dropsCoin = Math.random() < CONFIG.enemy.dropCoinChance;
  }

  update(player) {
    // Move towards player
    const dx = player.x - this.x;
    const dy = player.y - this.y;
    const distance = Math.sqrt(dx * dx + dy * dy);
    
    if (distance > 0) {
      this.x += (dx / distance) * this.speed;
      this.y += (dy / distance) * this.speed;
    }
  }

  draw(ctx) {
    ctx.beginPath();
    ctx.arc(this.x, this.y, this.radius, 0, Math.PI * 2);
    ctx.fillStyle = this.color;
    ctx.fill();
    ctx.closePath();
  }
}

class Bullet {
  constructor(x, y, angle) {
    this.x = x;
    this.y = y;
    this.radius = CONFIG.bullet.radius;
    this.color = CONFIG.bullet.color;
    const speed = CONFIG.bullet.speed;
    this.dx = Math.cos(angle) * speed;
    this.dy = Math.sin(angle) * speed;
  }

  update() {
    this.x += this.dx;
    this.y += this.dy;
  }

  draw(ctx) {
    ctx.beginPath();
    ctx.arc(this.x, this.y, this.radius, 0, Math.PI * 2);
    ctx.fillStyle = this.color;
    ctx.fill();
    ctx.closePath();
  }

  isOffScreen(canvas) {
    return (
      this.x < 0 || 
      this.x > canvas.width || 
      this.y < 0 || 
      this.y > canvas.height
    );
  }
}

class Coin {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.radius = CONFIG.coin.radius;
    this.color = CONFIG.coin.color;
    this.value = CONFIG.coin.value;
  }

  draw(ctx) {
    ctx.beginPath();
    ctx.arc(this.x, this.y, this.radius, 0, Math.PI * 2);
    ctx.fillStyle = this.color;
    ctx.fill();
    ctx.closePath();
  }
}