/**
 * Collision detection system
 */

function checkCollisions(player, bullets, enemies, coins, onEnemyHit, onCoinCollected) {
  // Bullet-Enemy collisions
  for (let i = bullets.length - 1; i >= 0; i--) {
    const bullet = bullets[i];
    
    for (let j = enemies.length - 1; j >= 0; j--) {
      const enemy = enemies[j];
      const dx = bullet.x - enemy.x;
      const dy = bullet.y - enemy.y;
      const distance = Math.sqrt(dx * dx + dy * dy);
      
      if (distance < bullet.radius + enemy.radius) {
        // Enemy hit
        onEnemyHit(enemy, j);
        bullets.splice(i, 1);
        break;
      }
    }
  }
  
  // Player-Coin collisions
  for (let i = coins.length - 1; i >= 0; i--) {
    const coin = coins[i];
    const dx = player.x - coin.x;
    const dy = player.y - coin.y;
    const distance = Math.sqrt(dx * dx + dy * dy);
    
    if (distance < player.radius + coin.radius) {
      // Collect coin
      onCoinCollected(coin, i);
    }
  }
}