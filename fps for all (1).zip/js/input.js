/**
 * Input handling for joysticks
 */

class Joystick {
  constructor(elementId, originX, originY) {
    this.active = false;
    this.x = 0;
    this.y = 0;
    this.originX = originX;
    this.originY = originY;
    this.element = document.getElementById(elementId);
    this.inner = this.element.querySelector('.inner');
    this.maxDistance = CONFIG.game.joystickMaxDistance;
    
    this.bindEvents();
  }

  bindEvents() {
    this.element.addEventListener('touchstart', (e) => {
      e.preventDefault();
      this.handleStart(e);
    });
    
    this.element.addEventListener('touchmove', (e) => {
      e.preventDefault();
      this.handleMove(e);
    });
    
    this.element.addEventListener('touchend', () => {
      this.handleEnd();
    });
  }

  handleStart(e) {
    const touch = e.touches[0];
    this.active = true;
    this.updatePosition(touch.clientX, touch.clientY);
  }

  handleMove(e) {
    if (!this.active) return;
    e.preventDefault();
    const touch = e.touches[0];
    this.updatePosition(touch.clientX, touch.clientY);
  }

  handleEnd() {
    this.active = false;
    this.x = 0;
    this.y = 0;
    this.inner.style.transform = 'translate(-50%, -50%)';
  }

  updatePosition(clientX, clientY) {
    const dx = clientX - this.originX;
    const dy = clientY - this.originY;
    const distance = Math.sqrt(dx * dx + dy * dy);
    
    if (distance > this.maxDistance) {
      const angle = Math.atan2(dy, dx);
      this.x = Math.cos(angle) * this.maxDistance;
      this.y = Math.sin(angle) * this.maxDistance;
    } else {
      this.x = dx;
      this.y = dy;
    }
    
    // Update visual position
    this.inner.style.transform = `translate(calc(-50% + ${this.x}px), calc(-50% + ${this.y}px))`;
  }
}