/**
 * Game configuration file
 */
const CONFIG = {
  player: {
    radius: 20,
    color: '#3498db',
    speed: 5
  },
  enemy: {
    baseRadius: 15,
    color: '#e74c3c',
    minSpeed: 1,
    maxSpeed: 3,
    dropCoinChance: 0.5
  },
  bullet: {
    radius: 5,
    color: '#ecf0f1',
    speed: 10
  },
  coin: {
    radius: 10,
    color: '#f1c40f',
    value: 1
  },
  game: {
    enemySpawnRate: 0.02, // Probability per frame
    joystickMaxDistance: 50
  }
};